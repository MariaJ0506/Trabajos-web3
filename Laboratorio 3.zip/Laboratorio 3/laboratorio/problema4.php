<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h2>problema 4</h2>
    <?php
    
    $ruta = $_SERVER["DOCUMENT_ROOT"] . "/2024/php_06/";

    
    include_once("codigos/conexion2.inc");

    
    $AuxSql = "SELECT f.film_id, f.title, COUNT(r.rental_id) AS times_rented, SUM(p.amount) AS total_generated
           FROM film f
           JOIN inventory i ON f.film_id = i.film_id
           JOIN rental r ON i.inventory_id = r.inventory_id
           JOIN payment p ON r.rental_id = p.rental_id
           WHERE r.rental_date BETWEEN 'start_date' AND 'end_date'
           GROUP BY f.film_id, f.title
           ORDER BY times_rented DESC
           LIMIT 10";

    $Regis = mysqli_query($conex, $AuxSql) or die(mysqli_error($conex));

    
    $i = 0;
    while ($fila = mysqli_fetch_array($Regis)) {
        $codigo[$i] = $fila["film_id"];
        $nombre[$i] = $fila["title"];
        $vecesAlquilada[$i] = $fila["times_rented"];
        $totalGenerado[$i] = $fila["total_generated"];
        $i++;
    }

  
    mysqli_free_result($Regis);

   
    $xml = "<?xml version='1.0' encoding='utf-8' ?>";
    $xml .= "<informacion>";
    $xml .= "   <generalidades>";
    $xml .= "      <empresa>";
    $xml .= "         <nombre>Universidad Técnica Nacional</nombre>";
    $xml .= "         <carrera>Tecnologías de la Información</carrera>";
    $xml .= "         <curso>Tecnologías y Sistemas Web III</curso>";
    $xml .= "      </empresa>";
    $xml .= "      <profesor>";
    $xml .= "         <nombre>Jorge Ruiz</nombre>";
    $xml .= "         <experiencia>Profesor en programación desde 1993</experiencia>";
    $xml .= "      </profesor>";
    $xml .= "   </generalidades>";
    $xml .= "   <top_peliculas>";

    for ($j = 0; $j < $i; $j++) {
        $xml .= "<pelicula>";
        $xml .= "   <codigo>" . $codigo[$j] . "</codigo>";
        $xml .= "   <nombre>" . $nombre[$j] . "</nombre>";
        $xml .= "   <veces_alquilada>" . $vecesAlquilada[$j] . "</veces_alquilada>";
        $xml .= "   <total_generado>" . $totalGenerado[$j] . "</total_generado>";
        $xml .= "</pelicula>";
    }

    $xml .= "   </top_peliculas>";
    $xml .= "</informacion>";

   
    $rutaArchivo = $ruta . "peliculas_mas_solicitadas.xml";

    try {
        $archivo = fopen($rutaArchivo, "w+");
        fwrite($archivo, $xml);
        fclose($archivo);
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }


    ?>
</body>

</html>