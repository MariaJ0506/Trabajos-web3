<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h2>problema 5</h2>
    <?php


    $ruta = $_SERVER["DOCUMENT_ROOT"] . "/2024/php_06/";


    include_once("codigos/conexion2.inc");

    $AuxSql = "SELECT f.film_id, f.title, f.description, f.release_year, c.name AS category, a.first_name, a.last_name
           FROM film f
           JOIN film_category fc ON f.film_id = fc.film_id
           JOIN category c ON fc.category_id = c.category_id
           JOIN film_actor fa ON f.film_id = fa.film_id
           JOIN actor a ON fa.actor_id = a.actor_id
           WHERE f.film_id = 'film_id'
           ORDER BY a.first_name, a.last_name";

    $Regis = mysqli_query($conex, $AuxSql) or die(mysqli_error($conex));

    $i = 0;
    while ($fila = mysqli_fetch_array($Regis)) {
        $codigo[$i] = $fila["film_id"];
        $nombre[$i] = $fila["title"];
        $descripcion[$i] = $fila["description"];
        $anio[$i] = $fila["release_year"];
        $categoria[$i] = $fila["category"];
        $actores[$i][] = $fila["first_name"] . " " . $fila["last_name"];
        $i++;
    }


    mysqli_free_result($Regis);


    $xml = "<?xml version='1.0' encoding='utf-8' ?>";
    $xml .= "<informacion>";
    $xml .= "   <film>";
    $xml .= "      <codigo>" . $codigo[0] . "</codigo>";
    $xml .= "      <nombre>" . $nombre[0] . "</nombre>";
    $xml .= "      <descripcion>" . $descripcion[0] . "</descripcion>";
    $xml .= "      <anio>" . $anio[0] . "</anio>";
    $xml .= "      <categorias>";


    $xml .= "         <categoria>" . $categoria[0] . "</categoria>";
    $xml .= "      </categorias>";


    $xml .= "      <actores>";
    for ($j = 0; $j < $i; $j++) {
        $xml .= "         <actor>";
        $xml .= "            <nombre>" . $actores[$j][0] . "</nombre>";
        $xml .= "         </actor>";
    }
    $xml .= "      </actores>";
    $xml .= "   </film>";
    $xml .= "</informacion>";

    $rutaArchivo = $ruta . "actores_pelicula.xml";

    try {
        $archivo = fopen($rutaArchivo, "w+");
        fwrite($archivo, $xml);
        fclose($archivo);
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }


    ?>
</body>

</html>