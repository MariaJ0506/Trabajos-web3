<?php
require('codigos/fpdf.php');

class PDF extends FPDF
{
    function Header()
    {
        $this->SetFont('Arial', 'B', 15);
        $this->Cell(80);
        $this->Cell(20, 10, utf8_decode('Laboratorio 3: Impresión de Películas'), 0, 0, 'C');
        $this->Ln(20);
    }

    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, utf8_decode('Página ') . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }

    function PrintCategory($categoryName)
    {
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(10, 10, '');
        $this->Cell(60, 10, $categoryName, 0, 1);
        $this->SetFont('Times', '', 12);
    }

    function PrintFilm($title, $stock, $year)
    {
        $this->Ln(3);
        $this->SetFont('Arial', '', 12);
        $this->SetFillColor(200, 220, 255);
        $this->Cell(70, 6, $title, 0, 0, 'L', true);
        $this->Cell(30, 6, $stock, 0, 0, 'C', true);
        $this->Cell(20, 6, $year, 0, 1, 'C', true);
        $this->Ln(4);
    }

    function PrintHeaders()
    {
        $this->Ln(3);
        $this->SetFont('Arial', 'B', 12);
        $this->SetFillColor(255, 255, 255);
        $this->Cell(70, 6, "Film", 0, 0, 'L', true);
        $this->Cell(30, 6, "Stock", 0, 0, 'C', true);
        $this->Cell(20, 6, "Año", 0, 1, 'C', true);
        $this->Ln(4);
    }
}

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times', '', 12);

include_once("codigos/conexion.inc");

$query = "
    SELECT
        c.name AS category,
        f.title AS film_title,
        COUNT(i.inventory_id) AS stock,
        f.release_year
    FROM
        category c
    JOIN
        film_category fc ON c.category_id = fc.category_id
    JOIN
        film f ON fc.film_id = f.film_id
    JOIN
        inventory i ON f.film_id = i.film_id
    GROUP BY
        c.name, f.title, f.release_year
    ORDER BY
        c.name, f.title;
";

$result = mysqli_query($conex, $query);

if (mysqli_num_rows($result) > 0) {
    $lastCategory = '';
    while ($row = mysqli_fetch_assoc($result)) {
        if ($lastCategory !== $row['category']) {
            $pdf->PrintCategory($row['category']);
            $lastCategory = $row['category'];
            $pdf->PrintHeaders();
        }
        $pdf->PrintFilm($row['film_title'], $row['stock'], $row['release_year']);
    }
} else {
    echo "No se encontraron resultados.";
}

mysqli_close($conex);
$pdf->Output();
?>

