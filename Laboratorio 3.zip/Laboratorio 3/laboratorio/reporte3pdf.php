<?php
require('codigos/fpdf.php');

class PDF extends FPDF
{
    function Header()
    {
        $this->SetFont('Arial', 'B', 15);
        $this->Cell(80);
        $this->Cell(20, 10, utf8_decode('Reporte de Ingresos'), 0, 0, 'C');
        $this->Ln(20);
    }

    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, utf8_decode('Página ') . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }

    function cols()
    {
        $anchoNombre = 80;
        $anchoGenero = 50;
        $anchoMonto = 30;

        $this->Ln(3); // Salto de línea
        $this->SetFont('Arial', 'B', 12); // Fuente negrita
        $this->SetFillColor(255, 255, 255); // Color de fondo blanco

        $this->Cell($anchoNombre, 6, "Nombre", 0, 0, 'L', true); 
        $this->Cell($anchoGenero, 6, "Genero", 0, 0, 'C', true);
        $this->Cell($anchoMonto, 6, "Monto", 0, 1, 'C', true);
        $this->Ln(4); // Salto de línea después de los encabezados
    }

    function ingreso($nombre, $genero, $monto)
    {
        $this->Ln(3); // Salto de línea
        $this->SetFont('Arial', '', 12);
        $this->SetFillColor(200, 220, 255); // Color para los datos de ingresos

        $anchoNombre = 80;
        $anchoGenero = 50;
        $anchoMonto = 30;

        $this->Cell($anchoNombre, 6, $nombre, 0, 0, 'L', true);
        $this->Cell($anchoGenero, 6, $genero, 0, 0, 'C', true);
        $this->Cell($anchoMonto, 6, number_format($monto, 2), 0, 1, 'C', true);
    }
}

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage(); 
$pdf->SetFont('Times', '', 12); 


include_once("codigos/conexion.inc");

$fecha_inicio = $_POST['fecha_inicio'];
$fecha_fin = $_POST['fecha_fin'];

$AuxSql = "
SELECT
    s.store_id AS id,
    CONCAT(a.address, ', ', a.district) AS nombre,
    c.name AS genero,
    SUM(p.amount) AS monto
FROM
    payment p
JOIN
    rental r ON p.rental_id = r.rental_id
JOIN
    inventory i ON r.inventory_id = i.inventory_id
JOIN
    film f ON i.film_id = f.film_id
JOIN
    film_category fc ON f.film_id = fc.film_id
JOIN
    category c ON fc.category_id = c.category_id
JOIN
    store s ON i.store_id = s.store_id
JOIN
    address a ON s.address_id = a.address_id
WHERE
    r.rental_date BETWEEN '$fecha_inicio' AND '$fecha_fin'
GROUP BY
    s.store_id, nombre, c.name
ORDER BY
    monto DESC;";

$Regis = mysqli_query($conex, $AuxSql);

if (mysqli_num_rows($Regis) > 0) {
    $pdf->cols();
    
    while ($row_Regis = mysqli_fetch_assoc($Regis)) {
        $pdf->ingreso($row_Regis['nombre'], $row_Regis['genero'], $row_Regis['monto']);
    }
} else {
    echo "No se encontraron registros.";
}

$pdf->Output();