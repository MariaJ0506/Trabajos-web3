<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require('codigos/fpdf.php');

class PDF extends FPDF
{
    function Header()
    {
        $this->SetFont('Arial', 'B', 15);
        $this->Cell(0, 10, 'Reporte de Facturas', 0, 1, 'C');
        $this->Ln(10);
    }

    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Página ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }

    function ClientInfo($cliente, $contacto, $ubicacion, $fechaInicio, $fechaFin)
    {
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 10, 'Cliente: ' . $cliente, 0, 1);
        $this->Cell(0, 10, 'Contacto: ' . $contacto, 0, 1);
        $this->Cell(0, 10, 'Ubicación: ' . $ubicacion, 0, 1);
        $this->Cell(0, 10, 'Período: ' . $fechaInicio . ' a ' . $fechaFin, 0, 1);
        $this->Ln(5);
    }

    function InvoiceHeader($factura, $fecha_facturacion, $empleado, $fecha_requerida, $fecha_despachada)
    {
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 10, 'Factura #: ' . $factura . ' | Fecha: ' . $fecha_facturacion, 0, 1);
        $this->Cell(0, 10, 'Empleado: ' . $empleado . ' | Requerida: ' . $fecha_requerida . ' | Despachada: ' . $fecha_despachada, 0, 1);
        $this->Ln(5);
    }

    function ProductCols()
    {
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(30, 10, 'Código', 1);
        $this->Cell(80, 10, 'Nombre', 1);
        $this->Cell(30, 10, 'Cantidad', 1);
        $this->Cell(30, 10, 'Precio Uni', 1);
        $this->Cell(30, 10, 'Descuento', 1);
        $this->Cell(30, 10, 'Total', 1);
        $this->Ln();
    }

    function ProductDetails($product_code, $product_name, $quantity, $unit_price, $discount)
    {
        $total = ($unit_price * $quantity) * (1 - $discount);
        $this->SetFont('Arial', '', 10);
        $this->Cell(30, 10, $product_code, 1);
        $this->Cell(80, 10, $product_name, 1);
        $this->Cell(30, 10, $quantity, 1);
        $this->Cell(30, 10, number_format($unit_price, 2), 1);
        $this->Cell(30, 10, number_format($discount * 100, 2) . '%', 1);
        $this->Cell(30, 10, number_format($total, 2), 1);
        $this->Ln();
        return $total;
    }
}

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times', '', 12);

include_once("codigos/conexion2.inc");

$customerID = $_POST['customerID'] ?? 'ALFKI';
$fechaInicio = $_POST['fechaInicio'] ?? '1994-08-04';
$fechaFin = $_POST['fechaFin'] ?? '1996-06-05';

$clienteSql = "
    SELECT  
        c.CompanyName AS cliente,  
        CONCAT(c.ContactTitle, ' ', c.ContactName) AS contacto,  
        CONCAT(c.Address, ', ', c.City, ', ', c.Country, ' ', c.PostalCode) AS ubicacion  
    FROM  
        customers c  
    WHERE  
        c.CustomerID = '$customerID'  
    LIMIT 1;
";
$clientResult = mysqli_query($conex, $clienteSql);
$clientData = mysqli_fetch_assoc($clientResult);

$facturaSql = "
    SELECT 
        o.OrderID AS factura,
        o.OrderDate AS fecha_facturacion,
        CONCAT(e.FirstName, ' ', e.LastName) AS empleado,
        o.RequiredDate AS fecha_requerida,
        o.ShippedDate AS fecha_despachada
    FROM 
        orders o
    JOIN 
        employees e ON o.EmployeeID = e.EmployeeID
    WHERE 
        o.CustomerID = '$customerID'  
        AND o.OrderDate BETWEEN '$fechaInicio' AND '$fechaFin';
";
$invoiceResult = mysqli_query($conex, $facturaSql);

$pdf->ClientInfo(
    $clientData['cliente'],
    $clientData['contacto'],
    $clientData['ubicacion'],
    date('d/M/Y', strtotime($fechaInicio)),
    date('d/M/Y', strtotime($fechaFin))
);

$totalAcumulado = 0;

while ($invoiceData = mysqli_fetch_assoc($invoiceResult)) {
    $pdf->InvoiceHeader(
        $invoiceData['factura'],
        date('d/M/Y', strtotime($invoiceData['fecha_facturacion'])),
        $invoiceData['empleado'],
        date('d/M/Y', strtotime($invoiceData['fecha_requerida'])),
        date('d/M/Y', strtotime($invoiceData['fecha_despachada']))
    );

    $pdf->ProductCols();

    $detailsSql = "
        SELECT 
            p.ProductID AS product_code,
            p.ProductName,
            od.Quantity,
            od.UnitPrice,
            od.Discount
        FROM 
            order_details od
        JOIN 
            products p ON od.ProductID = p.ProductID  
        WHERE 
            od.OrderID = " . $invoiceData['factura'] . "; 
    ";
    $detailsResult = mysqli_query($conex, $detailsSql);

    while ($productData = mysqli_fetch_assoc($detailsResult)) {
        $totalAcumulado += $pdf->ProductDetails(
            $productData['product_code'],
            $productData['ProductName'],
            $productData['Quantity'],
            $productData['UnitPrice'],
            $productData['Discount']
        );
    }

    $pdf->Cell(0, 10, 'Total de la Factura: ' . number_format($totalAcumulado, 2), 0, 1);
    $totalAcumulado = 0;
}

mysqli_close($conex);
$pdf->Output();
?>
