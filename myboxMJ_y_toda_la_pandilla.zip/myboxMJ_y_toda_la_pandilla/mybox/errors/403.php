<!doctype html>
<html>
<head>
    <title>Error 403</title>
    <meta http-equiv="refresh" content="6; url=../index.php">
</head>
<body>
    <?php
        echo "<h1 style='color: red'>Error 403</h1>";
        echo "<hr>";
        echo "<h3>Acceso denegado</h3><br>";
        echo "Usted va a ser redireccionado en unos instantes";
    ?>
</body>
</html>
